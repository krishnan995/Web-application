﻿using MediatR;

namespace RapidBlazor.Domain.Common;

public abstract class BaseEvent : INotification
{
}
