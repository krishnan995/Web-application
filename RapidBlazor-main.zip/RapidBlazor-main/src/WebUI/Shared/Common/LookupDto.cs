﻿namespace RapidBlazor.WebUI.Shared.Common;

public class LookupDto
{
    public int Id { get; set; }

    public string Title { get; set; } = string.Empty;
}
