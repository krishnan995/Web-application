﻿namespace RapidBlazor.WebUI.Shared.Authorization;

public static class CustomClaimTypes
{
    public const string Permissions = "permissions";
}
