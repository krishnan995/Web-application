﻿using RapidBlazor.WebUI.Shared.Common;

namespace RapidBlazor.WebUI.Shared.TodoLists;

public class TodosVm
{
    public List<LookupDto> PriorityLevels { get; set; } = new();

    public List<TodoListDto> Lists { get; set; } = new();
}
