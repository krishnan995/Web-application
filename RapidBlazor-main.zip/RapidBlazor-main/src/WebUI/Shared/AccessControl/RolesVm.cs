﻿namespace RapidBlazor.WebUI.Shared.AccessControl;

public class RolesVm
{
    public IList<RoleDto> Roles { get; set; } = new List<RoleDto>();
}
