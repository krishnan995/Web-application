﻿var app = {};

app.hideModal = function (element) {
    bootstrap.Modal.getInstance(element).hide();
}