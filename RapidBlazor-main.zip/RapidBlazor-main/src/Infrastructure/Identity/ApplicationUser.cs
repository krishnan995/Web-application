﻿using Microsoft.AspNetCore.Identity;

namespace RapidBlazor.Infrastructure.Identity;

public class ApplicationUser : IdentityUser
{
}
