global using BoDi;
global using FluentAssertions;
global using Microsoft.Playwright;
global using RapidBlazor.WebUI.AcceptanceTests.Pages;
global using TechTalk.SpecFlow;
